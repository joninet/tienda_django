# edshop
Proyecto de E-Commerce con Django para Edteam
